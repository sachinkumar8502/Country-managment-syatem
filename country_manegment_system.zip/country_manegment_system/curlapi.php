<!-- <?php 
// $url = "http://localhost/librarymangment/admin/demo1.php";
// //Initialise the cURL var
// $ch = curl_init();
// //Set the Url
// curl_setopt($ch, CURLOPT_URL, $url);

// //Get the response from cURL
// curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);

// $result = curl_exec($ch);

// curl_close($ch);

// $resul = json_decode($result,true);

// echo "<pre>";
// print_r($resul);

// if(( is_array($resul)) && ($resul['succes'])){
// 	$i=0;
//    // echo count($order_data['data']);
//      foreach ($resul['data'] as $row){

//      	$librerydata = $row;

//      	$book_id = $librerydata['book_id'];
//      	$title =  $librerydata['title'];
//      	$category_name = $librerydata['category_name'];
//      	//print_r($category_name);
//      }
// 	}


?> -->
<!DOCTYPE html>
<html>
<head>
	<title>API</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>


</head>
<body>



 <script type="text/javascript">
  	
 
      	$(document).ready(function(){
   
		$.ajax({
		      type: "GET",
		      url: "http://localhost/librarymangment/admin/demo1.php",
		      dataType: 'json',
		     


		      success: function(data){
		          alert(data);
		           console.log(data);
		           console.log(data.data);



		          $.each(data.data,function(key, value) {
		          	$.each(value,function(innerkey,innervalue){

		          		console.log(innervalue);

		          	});



					  //console.log(value);
					});
							            

		          
		},
		     
		  });

	return false;




		});
	

      		
     

	
</script>
</body>
</html>