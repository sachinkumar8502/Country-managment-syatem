<?php 
include('connection.php'); 
if (isset($_POST["district_id"])) {
    $district_id= $_POST['district_id'];
    $querythesil = "SELECT * FROM tbltehsil WHERE district_id = '$district_id'ORDER BY tehsil_name ASC";
    $run_querythesil = mysqli_query($conn, $querythesil);
    $count = mysqli_num_rows($run_querythesil);
    if($count > 0){
        echo '<option value="">Select thesil</option>';
        while($row = mysqli_fetch_array($run_querythesil)){
		$tehsil_id=$row['tehsil_id'];
        $tehsil_name=$row['tehsil_name']; 
       echo "<option value='$tehsil_id'>$tehsil_name</option>";
        }
    }else{
        echo '<option value="">thesil not available</option>';
    }
    
}



?>