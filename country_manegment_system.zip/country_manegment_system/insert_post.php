<?php
include('connection.php');
//print_r($_POST);
if(isset($_POST["country_id"])){
    
  $country_id= $_POST['country_id'];

    $query ="SELECT * FROM tblstate WHERE country_id = '$country_id' ORDER BY state_name ASC";
    $run_query = mysqli_query($conn, $query);
    $count = mysqli_num_rows($run_query);

    if($count > 0){
        echo '<option value="">Select state</option>';
        
        while($row = mysqli_fetch_array($run_query)){
            $state_id=$row['state_id'];
            $state_name=$row['state_name'];
        echo "<option value='$state_id'>$state_name</option>";
        }
    }else{
        echo '<option value="">State not available</option>';
    }
}


if(isset($_POST["state_id"])){
  $state_id= $_POST['state_id'];
  
    $querydistrict = "SELECT * FROM tbldistrict WHERE state_id = '$state_id'ORDER BY district_name ASC";
    $run_querydistrict = mysqli_query($conn, $querydistrict);
    $count = mysqli_num_rows($run_querydistrict);
    if($count > 0){
        echo '<option value="">Select city</option>';
        while($row = mysqli_fetch_array($run_querydistrict)){
        $district_id=$row['district_id'];
        $district_name=$row['district_name']; 
        echo "<option value='$district_id'>$district_name</option>";
        }
    }else{
        echo '<option value="">district not available</option>';
    }
} 
?>