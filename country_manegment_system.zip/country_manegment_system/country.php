<?php 

error_reporting(0);
include('connection.php');
if (isset($_GET['country_id'])) {
    
    $id = $_GET['country_id'];

    
    $sql = "SELECT * FROM `tblcountry` WHERE country_id ='$id'";
 
   $retval = $conn->query($sql);
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($conn));
  }

  $row = mysqli_fetch_array($retval, MYSQLI_ASSOC);

$id         = $row['country_id'];
$country         = $row['country_name'];

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Country</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
<style type="text/css">
  
li a.active {
  background-color: #04AA6D;
  color: white;
}

li a:hover:not(.active) {
  background-color:#bda047;
  color: white;
}



.overlay{
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 999;
    background: rgba(255,255,255,0.8) url("img/loader3.gif") center no-repeat;
}

</style>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-light text-uppercase">
  <a class="navbar-brand text-dark" href="cms_dashbord.php">Country Manegment System(CMS)</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="container-fluid">
<ul class="nav navbar-nav navbar-center">
 
  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Country</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="country.php">Add New Country</a>
      <a class="dropdown-item text-success" href="display_country.php">View Country</a>
      
    </div>
  </li>

  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>States</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="state.php">Add New State</a>
      <a class="dropdown-item text-success" href="display_state.php">View state</a>
      
    </div>
  </li>

   <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>District</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="district.php">Add New District</a>
      <a class="dropdown-item text-success" href="display_district.php">View District</a>
      
    </div>
    </li>
   <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Tehsil</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="thesil.php">Add New Tehsil</a>
        <a class="dropdown-item text-success" href="display_thesil.php">View Tehsil</a>
        
      </div>
    </li>

    <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Pincode</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="Pincode.php">Add New Pincode</a>
        <a class="dropdown-item text-success" href="display_pincode.php">View Pincode</a>
        
      </div>
    </li>

    <li class="nav-item">
      <a href="auto_complete.php" class="nav-link"><b>Users</b></a>
    </li>
   
</ul>
</div>
  </div>
</nav>


<form action="" method="post"enctype="" id="validatedemo">
<section class="my-5">
  <div class="py-5">

<h2 class="text-center text-success"> 
       <?php 
                if (isset($_GET['country_id'])) {

            ?>
               Update Country
            <?php }else { ?>
  
            Add Country 
            <?php } ?>
    </h2>
    
    <div class="w-50 m-auto ">
  <div class="form-group">
    
  <div class="alert alert-warning alert-dismissible fade show " id="alertbox" role="alert">
  <strong>Well done!</strong> data insert succesfully
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  
</div>
<script>

$(document).ready(function(){
  $('#alertbox').hide();
});

</script>


    <input type="hidden" name="hiddenIdx" id="hiddenIdx" value="<?php echo $id; ?>">

          <label class="text-success" for="country">Country name<sup class="text-danger">*</sup></label>
          <input type="text" name="country" id="country" class="form-control" value="<?php echo $country; ?>">
          <!--<label id="country-error" class="error text-danger" for="country"></label>-->
        </div>
        <button type="submit"  class="btn btn-primary  disabled">
        
          <?php 
                if (isset($_GET['country_id'])) {

            ?>
             Update country
            <?php }else { ?>
  
            InsertCountry
            <?php } ?>
            
        </button>
        <div class="overlay"></div>
        </form>
    </div>
  </div>
</section>
<script type="text/javascript">
//function spinner() {
   
       
  //}
	$(document).ready(function(){
      $('#validatedemo').validate({
        // $("Textbox").rules("add", { regex: /^[a-zA-Z'.\s]{1,40}$/ });
			rules:{

				country:{
					       required:true,
                  minlength:2

				},

			},

			messages:{

				country:{
					           required:"**please enter your country",
                    minlength:"**Your country must consist of at least 2 characters."
			},
		},
		 errorPlacement: function (error, element) {
                  console.log(element);
                  error.appendTo(element.parent());
  },
  submitHandler: function (form) {
      var datax = $(form).serializeArray().reduce(function(obj, item) {
          obj[item.name] = item.value;
          return obj;
      }, {});
     console.log(datax);

        var hiddenIdx = datax['hiddenIdx'];
        console.log(hiddenIdx);
        if (( hiddenIdx == '' ) || ( typeof hiddenIdx === 'undefined' ) || ( hiddenIdx == '0')) {

          
          document.getElementsByClassName("overlay")[0].style.display = "block";

         

          

   $.ajax({
          type: "POST",
          url: "http://localhost/country_manegment_system/country_post.php",

          data:'country='+datax['country'],

          success: function(data){
                //alert(data);
                //sweetalert(data);
                console.log(data);

               if(data == 'country_name'){
              $('#country-error').show();
              $('#country-error').html('country already exists!');
              $('#country').focus();
            }else if(data == 'success'){
              $('#alertbox').show();
              $('.overlay').hide();
              $(".disabled").attr("disabled", true);
              document.getElementById("validatedemo").reset();
              //window.location.href = "state.php";
            }else{
                //alert(datax);
                $('#alertbox').html('<div class="alert alert-warning alert-dismissible fade show" id="alertbox" role="alert">data not insert<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>')
            }
},
          error: function(xhr, options, error) {
               alert(error);
          }
      });
 }else{
  //console.log('i am here');
  document.getElementsByClassName("overlay")[0].style.display = "block";
  $.ajax({
            type: "POST",
            url: "http://localhost/country_manegment_system/Update_country.php",

            data:'country='+datax['country']+'&country_id='+datax['hiddenIdx'],

            success: function(data){
               alert(data);
                 console.log(data);
                if (data == 'Updated'){
                  //$('#alertbox').show();
                  //$('#alertbox').html('<div class="alert alert-warning alert-dismissible fade show" id="alertbox" role="alert">data updated succesfully<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>')
                  $('.overlay').hide();

                  window.location.href = "http://localhost/country_manegment_system/display_country.php";

                }else{
                  alert('somthing want wrong');
                }
                
                 //page return
                //window.location.href = "http://localhost/librarymangment/admin/displaybook.php";
                //document.getElementById("validateform").reset();
              },
            error: function(xhr, options, error) {
                 alert(error);
            }
        });

}
      return false;
  }

		});

	});
</script>
</body>
</html>