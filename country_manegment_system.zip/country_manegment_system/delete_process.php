<?php
include("connection.php");
//print_r($_POST); 
$deledata = trim($_POST['id']);

   		if(!empty($deledata)){
        $qry = "DELETE FROM `insert_tbl_data` WHERE id ='$deledata'";
        $result=mysqli_query( $conn,$qry);
        if($result){

            echo 'Deleted succesfully';

            }else{
                echo 'error';

            }
        }else{
        		echo 'id empty !';
        }

?>