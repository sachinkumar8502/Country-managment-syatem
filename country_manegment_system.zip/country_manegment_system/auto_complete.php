<?php 

   include('connection.php');
    $query = "SELECT * FROM tblcountry  ORDER BY country_name ASC";
    $run_query = mysqli_query($conn, $query);
    $count = mysqli_num_rows($run_query);
?>
<!DOCTYPE html>
<html>
<head>
	<title>auto fields</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
</head>
<body>

<style type="text/css">
  
  li a.active {
  background-color: #04AA6D;
  color: white;
}

li a:hover:not(.active) {
  background-color:#bda047;
  color: white;
}
.overlay{
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 999;
    background: rgba(255,255,255,0.8) url("img/loader2.gif") center no-repeat;
}


</style>
	  <nav class="navbar navbar-expand-lg navbar-light bg-light ">
  <a class="navbar-brand text-dark" href="cms_dashbord.php">Country Manegment System(CMS)</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="container-fluid">
<ul class="nav navbar-nav navbar-center">
 
  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Country</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="country.php">Add New Country</a>
      <a class="dropdown-item text-success" href="display_country.php">View Country</a>
      <a class="dropdown-item" href="#"></a>
    </div>
  </li>

  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>States</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="state.php">Add New State</a>
      <a class="dropdown-item text-success" href="display_state.php">View state</a>
      <a class="dropdown-item" href="#"></a>
    </div>
  </li>

   <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>District</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="district.php">Add New District</a>
      <a class="dropdown-item text-success" href="display_district.php">View District</a>
      <a class="dropdown-item" href="#"></a>
    </div>
    </li>
   <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Tehsil</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="thesil.php">Add New Tehsil</a>
        <a class="dropdown-item text-success" href="display_thesil.php">View Tehsil</a>
        <a class="dropdown-item" href="#"></a>
      </div>
    </li>

    <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Pincode</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="Pincode.php">Add New Pincode</a>
        <a class="dropdown-item text-success" href="display_pincode.php">View Pincode</a>
        <a class="dropdown-item" href="#"></a>
      </div>
    </li>

    <li class="nav-item">
      <a href="auto_complete.php" class="nav-link"><b>Users</b></a>
    </li>
   
</ul>
</div>
  </div>
</nav>

<form action="" method="post"enctype="" id="validateform">
<section class="my-5">
  <div class="py-5">
    
    <div class="w-50 m-auto ">
      <h2 class="text-center text-success">CMS Form</h2>

    	<div class="form-group">
          <label class="text-success" for="country">Country name<sup class="text-danger">*</sup></label>
        <select class="form-select form-control " id="country" name="country" aria-label="Default select example">
          <label id="country-error" class="error text-danger" for="country"></label>
          <option value="default" >Select country</option>
          <?php
        if($count > 0){
            while($row = mysqli_fetch_array($run_query)){
				            $country_id=$row['country_id'];
				            $country_name=$row['country_name'];

                echo "<option value='$country_id'>$country_name</option>";
            }
        }else{
            echo '<option value="">Country not available</option>';
        }
        ?>
  		</select>
        </div>

         <div class="form-group">
          <label class="text-success" for="State">State name<sup class="text-danger">*</sup></label>
           <select class="form-select form-control " id="state" name="state" aria-label="Default select example">
          <option  value="default">Select state</option>

         
           
        </select>
        </div>

      <div class="form-group">
          <label class="text-success" for="district">District name<sup class="text-danger">*</sup></label>
          <select class="form-select form-control"id="district"name="district" aria-label="Default select example"  >
          <option  value="selectdistrict">Select district</option>
           
        </select>
        </div>
         <div class="form-group">
          <label class="text-success" for="thesil">Thesil name<sup class="text-danger">*</sup></label>
           <select class="form-select form-control " id="thesil" name="thesil" aria-label="Default select example"  >
          <option value="selectthesil" >Select thesil</option>
          
        </select>
        </div>

         <div class="form-group">
          <label class="text-success" for="pincode">Enter area pincode<sup class="text-danger">*</sup></label>
          <select class="form-select form-control " id="pincode" name="pincode" aria-label="Default select example"  >
          <option value="selectpincode" >Select pincode</option>
           
        </select>
        </div>
        <button type="submit" class=" btn btn-primary  disabled"  onclick="spinner()">Insert</button>


    <button type="button" class="btn btn-success text-white">
        <a href="view_cms_data.php">View data</a>
    </button>

    
    </form>
    </div>
  </div>
</section>
<div class="overlay"></div>
                

<script type="text/javascript">
function spinner() {
   
       
  }
$(document).ready(function(){
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'http://localhost/country_manegment_system/insert_post.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#state').html(html);
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            
        }
    });
    


    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'http://localhost/country_manegment_system/insert_post.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#district').html(html);
                     
                }
            }); 
        }else{
            $('#district').html('<option value="">Select state first</option>');
            
        }
    });



    $('#district').on('change',function(){
        var districtID = $(this).val();
        if(districtID){
            $.ajax({
                type:'POST',
                url:'http://localhost/country_manegment_system/district_insert_post.php',
                data:'district_id='+districtID,
                success:function(html){
                    $('#thesil').html(html);
                    
                }
            }); 
        }else{
           
             $('#thesil').html('<option value="">Select district first</option>'); 
               
        }
    });

$('#district').on('change',function(){
        var district = $(this).val();
        if(district){
            $.ajax({
                type:'POST',
                url:'http://localhost/country_manegment_system/pincode_insert_post.php',
                data:'district_id='+district,
                success:function(html){
                    $('#pincode').html(html);
                     
                }
            }); 
        }else{
           $('#pincode').html('<option value="">Select district first</option>');  
        }
    });

$.validator.addMethod("valueNotEquals", function(value, element, arg){
  return arg !== value;
 }, "Value must not equal arg.");

$('#validateform').validate({

  rules: {
   country:{ 
    valueNotEquals: "default" 
  }
  
  },

  messages: {
   country: {

    valueNotEquals: "Please select  your country !"

     }
     
  }, 



errorPlacement: function (error, element) {
                  console.log(element);
                  error.appendTo(element.parent());
  },
  submitHandler: function (form) {
      var datax = $(form).serializeArray().reduce(function(obj, item) {
          obj[item.name] = item.value;
          return obj;
      }, {});
     console.log(datax);

     document.getElementsByClassName("overlay")[0].style.display = "block";


   $.ajax({
          type: "POST",
          url: "http://localhost/country_manegment_system/cms_data_insert_by_post.php",

          data:'country='+datax['country']+'&state='+datax['state']+'&district='+datax['district']+'&thesil='+datax['thesil']+'&pincode='+datax['pincode'],
          

          success: function(data){
                //alert(datax);
               console.log(data);

               
             if(data == 'success'){
              $('.overlay').hide()
              $(".disabled").attr("disabled", true);
              
              document.getElementById("validateform").reset();
              
            }else{
                alert(datax);
            }
},
          error: function(xhr, options, error) {
               alert(error);
          }
      });
      return false;
  }


});
});
</script>

</body>
</html>