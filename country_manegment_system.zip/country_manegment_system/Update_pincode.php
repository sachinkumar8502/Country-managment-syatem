<?php 
include('connection.php');
//print_r($_POST);

 $country	=   $_POST['country'];
$state_id 		=   $_POST['state'];
$district_id    = $_POST['district'];
$pincode		=  $_POST['pincode'];
$pincode_id 		=  $_POST['pincode_id'];

   
   $sql = 'UPDATE `tblpincode` SET `country_id`="'.$country.'" , `state_id`="'.$state_id.'", `district_id`="'.$district_id.'" ,`pin_code`="'.$pincode.'"  WHERE pincode_id ="'. $pincode_id.'" ';
       
   $retval = $conn->query($sql);
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($conn));
   }
    echo 'Updated';
?>