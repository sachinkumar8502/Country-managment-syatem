<?php 
include('connection.php');
    
  $sql = 'SELECT * FROM `tblcountry`';


   $result = $conn->query($sql);
   if(!$result){
      die('Could not enter data: ' . mysqli_error($conn));
  }



?>

<!DOCTYPE html>
<html>
<head>
	<title>table</title>

  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
  <script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
  <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
  <script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">

</head>
<body>
<table class="table table-striped table-dark">
	<tr>
		<th>id</th>
		<th>country</th>
		<th>state</th>
		<th>action</th>
	</tr>

	<?php
    $i=0;
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
      $i++;
      
      $country_id = $row['country_id']; 
      
      $sql1 = 'SELECT * FROM `tblstate` WHERE country_id = '. $country_id;
          $result1 = $conn->query($sql1);
          
      ?>

	<tr>
		<td><?php echo $i; ?></td>
		<td><?php echo ucfirst($row['country_name']); ?></td>
	
		<td colspan="3">
			<table class="table table-striped table-dark">
			<?php
						$z=0;
					while ($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC)) {
						$z++;
    
    ?>
		<tr>
				<td><?php echo  ucfirst($row1['state_name']) ;?></td>
				<td>
				<button class="btn btn-success bg-dark">
          <a onclick="deleteRecord(this.title);"title="<?php echo $row1['state_id']; ?>"><i class="fas fa-trash-alt"></i>Delete </a>
      </button>

        <button class="btn btn-success bg-dark ">
        <a class="text-white " style="text-decoration: none;" href="state.php?state_id=<?php echo $row1['state_id']; ?>" title="<?php echo $row1['state_id']; ?>" onclick="return confirm('Are you sure you want to update?');"><i class="fas fa-edit"></i>Edit</a>
      </button>
					</td>
				</tr>
				<?php } ?>
			</table>
		</td>
		
			
				
			
			
		
	</tr>
			
<?php } ?>
</table>
</body>
</html>