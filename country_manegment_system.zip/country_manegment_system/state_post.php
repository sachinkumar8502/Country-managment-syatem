<?php
include('connection.php');
//print_r($_POST);
$country_id = $_POST['country'];
  $state=   $_POST['state'];
  

 
  
  $sql ='INSERT INTO `tblstate`(`country_id`, `state_name`)
  VALUES ("'.$country_id.'","'.$state.'")';

  $retval = $conn->query($sql);
  if(! $retval ) {
     die('Could not enter data: ' . mysqli_error($conn));
  }
  echo "success";
?>
