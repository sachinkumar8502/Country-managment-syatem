<?php
include("connection.php");
 
$deledata = trim($_POST['country_id']);

   		if(!empty($deledata)){
        $qry = "DELETE FROM `tblcountry` WHERE country_id ='$deledata'";
        $result=mysqli_query( $conn,$qry);
        if($result){

            echo 'Deleted';

            }else{
                echo 'error';

            }
        }else{
        		echo 'id empty !';
        }

?>