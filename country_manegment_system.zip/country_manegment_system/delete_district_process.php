<?php
include("connection.php");
 
$deledata = trim($_POST['district_id']);

        if(!empty($deledata)){
        $qry = "DELETE FROM `tbldistrict` WHERE district_id ='$deledata'";
        $result=mysqli_query( $conn,$qry);
        if($result){

            echo 'Deleted';

            }else{
                echo 'error';

            }
        }else{
                echo 'id empty !';
        }

?>