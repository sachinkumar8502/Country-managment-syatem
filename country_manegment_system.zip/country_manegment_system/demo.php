<?php 
$abc2 = array('sachin' =>array(
                            'age'=>'23' ,
                            'Mobile'=>'25446455465',
                            'DOB' => '05/08/2001'
                          ) , 
                'Krishan' =>array(
                      'age'=>'24',
                      'Mobile'=>'2548976514654',
                      'DOB' => '07/07/1996'

                ), 
                'monu' =>array(
                      'age'=>'24',
                      'Mobile'=>'2548976514654',
                      'DOB' => '07/07/1996'

                )
              );
//echo "<pre>";
//echo "<br>";
//print_r($abc2);

?>
<!DOCTYPE html>
<html>
<head>
	<title>view data</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
</head>
<body>


<div class="card">
  <div class="card-header">
    <b>View States</b>
  </div>
  <div class="card-body">
    <table class="table table-bordered border-primary">
 
    <tr>
      <th scope="row">name</th>
      <th scope="row">info</th>

</tr>
 <?php 
foreach ($abc2 as $key => $value) {
  ?>
    <tr>
      <td rowspan="4"><?php echo $key; ?></td>
    </tr>
<?php
  foreach ($value as $k => $v) {

 ?>
      <tr>
          <td><?php echo $k .'-'.$v; ?></td>
      </tr>

       
<?php } } ?>

</table>
</div>
</div>

</body>
</html>




