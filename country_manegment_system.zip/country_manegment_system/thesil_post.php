<?php
include('connection.php');
//print_r($_POST);
  
  $country_id = $_POST['country'];
  $state_id = $_POST['state'];
  $district=   $_POST['district'];
  $thesil=   $_POST['thesil'];

  $thesilquary= "SELECT * FROM tbltehsil WHERE tehsil_name = '$thesil'";
  $quary = mysqli_query($conn,$thesilquary);
  $thesil_count = mysqli_num_rows($quary);
  if ($thesil_count > 0) {
    echo "tehsil_name";
    die();
  }
  
  $sql ='INSERT INTO `tbltehsil`(`country_id`, `state_id`, `district_id`, `tehsil_name`)
  VALUES ("'.$country_id.'" , "'.$state_id.'" , "'.$district.'" , "'.$thesil.'")';

  $retval = $conn->query($sql);
  if(! $retval ) {
     die('Could not enter data: ' . mysqli_error($conn));
  }
  echo "success";
?>