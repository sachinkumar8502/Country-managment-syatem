<?php
include("connection.php");

$deledata = trim($_POST['tehsil_id']);

        if(!empty($deledata)){
        $qry = "DELETE FROM `tbltehsil` WHERE tehsil_id ='$deledata'";
        $result=mysqli_query( $conn,$qry);
        if($result){

            echo 'Deleted';

            }else{
                echo 'error';

            }
        }else{
                echo 'id empty !';
        }

?>
