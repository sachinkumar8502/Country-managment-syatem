<?php 
$abc2 = array('sachin' =>array(
                            'age'=>'23' ,
                              'Mobile' => array(
                                  'Mob'=>'2548976514654',
                                  'moghhjk' => '75445421421'
                            
                          ),
                            'DOB' => '05/08/2001'

                        ) , 
                'Krishan' =>array(
                      'age'=>'24',
                      'Mobile' => array(
                              'Mob'=>'2548976514654',
                              'moghhjk' => '75445421421'
                            
                          ),
                      'DOB' => '07/07/1996'

                ), 
                'monu' =>array(
                      'age'=>'24',
                      'Mobile' => array(
                              'Mob'=>'2548976514654',
                              'moghhjk' => '75445421421'
                            
                          ),
                      'DOB' => '07/07/1996'

                ),
                'mohit' =>array(
                      'age'=>'20',
                      'Mobile' => array(
                              'Mob'=>'2548976514654',
                              'moghhjk' => '75445421421'
                            
                          ),
                      'DOB' => '07/07/1999'

                ),



              );





 //////<td><?php echo $row['country_name']; ?></td>
     ////// <td><?php echo $row['state_name']; ?></td>

      <!--<td><?php echo $row['country_name']; ?></td>-->
      <!--<td><?php echo $row['state_name']; ?></td>-->


//$total =  count($abc2);
//echo  $abc2[0];
//print_r($total);

//print_r($abc2);

?>
<!DOCTYPE html>
<html>
<head>
	<title>view data</title>
	
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	
</head>
<body>


<div class="card">
  <div class="card-header">
    <b>View States</b>
  </div>
  <div class="card-body">
    <table class="table table-bordered border-primary">
 
    <tr>
      <th scope="row">name</th>
      <th scope="row">info</th>

</tr>



 <?php
 $total =  count($abc2);
 $sssd  = array_keys($abc2);
 //print_r(array_values($abc2));
 //print_r($sssd);
 //$value = array_values($abc2);
 for($i=0; $i <$total ; $i++) { 
  ?>

  <tr>
      <td rowspan="4"><?php echo $sssd[$i] ; ?></td>
    </tr>
    <?php  
    $keys = $abc2[$sssd[$i]];
    //$valueKey = $value[$i];
    //print_r($abc2[$sssd[$i]]);
      $sssd1  = array_keys($keys);

      for($k=0; $k <count($keys); $k++){ 
          //print_r($keys);
         //print_r ($sssd1);
        ?>
        <tr>
          <td><?php echo $sssd1[$k] .' - '. $keys[$sssd1[$k]] ; ?></td>
        </tr>

        <?php
        if ( $sssd1[$k] == $sssd1[1]) {

          $ghj = [$sssd1[$k]];
            $jjj = $abc2[$sssd[$i]];
            $ghhj = $jjj[$ghj[$g]];

          //$hkjm = $sssd1[$ghj[$k]];
          $value = array_values($ghj);
          $keysss = array_keys($jjj);
          $gvhhb = array_keys($keysss);
          //$count = count($jjj[$ghj[$g]]);
              //print_r($jjj[$keysss[$g]]);
          for ($g=0; $g <count($jjj) ; $g++) { 
            ?>

           
         
          

         
          
         <?php ?>

         
           





<?php } } }  }  ?>
 
</table>
</div>
</div>

</body>
</html>



SELECT ts.state_id,ts.country_id,ts.state_name,tc.country_name 
  FROM tblstate AS ts
   INNER JOIN tblcountry AS tc ON tc.country_id=ts.country_id



   display_district = SELECT  td.district_id,td.state_id,td.country_id,td.district_name,tc.country_name,ts.state_name 
  FROM tbldistrict AS td
   INNER JOIN tblcountry AS tc ON tc.country_id=td.country_id
   INNER JOIN tblstate AS ts ON ts.state_id=td.state_id







 <td>
        <button class="btn btn-success bg-dark">
          <a onclick="deleteRecord(this.title);"title="<?php echo $row1['state_id']; ?>"><i class="fas fa-trash-alt"></i>Delete </a>
      </button>

        <button class="btn btn-success bg-dark ">
        <a class="text-white " style="text-decoration: none;" href="state.php?state_id=<?php echo $row1['state_id']; ?>" title="<?php echo $row1['state_id']; ?>" onclick="return confirm('Are you sure you want to update?');"><i class="fas fa-edit"></i>Edit</a>
      </button >
      </td>








    
  Array
(
    [state_id] => 6
    [country_id] => 8
    [state_name] => panjab
    [country_name] => india
)


    
    Array
(
    [state_id] => 7
    [country_id] => 8
    [state_name] => utterprdesh
    [country_name] => india
)


    
    Array
(
    [state_id] => 8
    [country_id] => 12
    [state_name] => Arun Kshetra
    [country_name] => nepal
)


    
    Array
(
    [state_id] => 12
    [country_id] => 12
    [state_name] => Kathmandu Kshetra
    [country_name] => nepal
)


    
    Array
(
    [state_id] => 18
    [country_id] => 12
    [state_name] => Gandak Kshetra
    [country_name] => nepal
)


    
    Array
(
    [state_id] => 19
    [country_id] => 12
    [state_name] => Karnali Kshetra
    [country_name] => nepal
)


    
    Array
(
    [state_id] => 20
    [country_id] => 8
    [state_name] => UP
    [country_name] => india
)






<!DOCTYPE html>
<html>
<body>
<style>
th,td {
 border:1px solid red;
}
</style>

<h2>Basic HTML Table</h2>

<table style="width:100% ; border:1px solid red" >
  <tr>
    <th>Firstname</th>
    <th>Lastname</th> 
    <th>Age</th>
  </tr>
  
  <tr>
    <td>Jill</td>
    <td colspan="2">
    
            <table>

              <tr>
                      <td>state</td>
                       <td>button</td>
              </tr>
              
               <tr>
                      <td>Smith</td>
                       <td>Smith1</td>
              </tr>
               <tr>
                      <td>Smith</td>
                       <td>Smith1</td>
              </tr>

            </table>
    
    </td>
    
  </tr>
  
</table>

</body>
</html>
<!DOCTYPE html>
<html>
<body>
<style>
th,td {
 border:1px solid red;
}
</style>

<h2>Basic HTML Table</h2>

<table style="width:100% ; border:1px solid red" >
  <tr>
    <th>Firstname</th>
    <th>Lastname</th> 
    <th>Age</th>
  </tr>
  
  <tr>
    <td>Jill</td>
    <td colspan="2">
    
            <table>

              <tr>
                      <td>state</td>
                       <td>button</td>
              </tr>
              
               <tr>
                      <td>Smith</td>
                       <td>Smith1</td>
              </tr>
               <tr>
                      <td>Smith</td>
                       <td>Smith1</td>
              </tr>

            </table>
    
    </td>
    
  </tr>
  
</table>

</body>
</html>








<div class="card">
  <div class="card-header">
    <b>View Thesil</b>
  </div>
  <div class="card-body">
    <table class="table ">
 
    <tr>
      <th scope="col">id</th>
      <th scope="col">Country</th>
      <th scope="col">state</th>
      <th scope="col" >district</th>
      <th scope="col">Thesil</th>
      <th scope="col">Action</th>
  </tr>
      

  <tr>
      <td>1</td>
      <td>india</td>
      <td colspan="4">
        <table class="table">
              <tr>
                  <td>state</td>
              <td>
                  <table class="table">
                        <tr>
                              <td>district</td>
                              <td >
                                    <table class="table">
                                            <tr>
                                              <td>thesil</td>
                                              <td> pincode</td>
                                                  <td>
                                                        <button>edit</button>
                                                        <button>delete</button>
                                                  </td>
                                            </tr>
                                    </table>
                              </td>
                        </tr>
                  </table>


              </td>


            </tr>

        </table>


      </td>


  </tr>
  
   
</table>
   
  </div>
</div>




