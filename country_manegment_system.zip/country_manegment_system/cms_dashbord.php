<?php
include('function.php');

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> CMS DASHBORD</title>
    <!-- Google Font: Source Sans Pro -->
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Google Font: Source Sans Pro -->
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
 <style media="screen">

 nav.navbar.navbar-expand-md.bg-dark.navbar-dark {
  margin: 0px 0px 0px 0px;
  padding: 20px 18px 23px 30px;
}
strong {
   font-weight: bolder;
   margin: 0 0px 0px 125px;
}
.navbar-light .navbar-nav .nav-link {
    color: #a09000;
}
.dropdown-item:hover {
    color: #16181b;
    text-decoration: none;
    background-color: #2196f3;
}
marquee {
    color: red;
    font-family: monospace;
}
.row {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: 0px;
margin-left: 0px;
}
hr {
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 0;
    border-top: 3px solid lightblue;
}
 </style>

  </head>
  <body>
   
   

<h3>CMS Dashbord</h3>
<hr>
<div class="row">
  <div class="col-md-4">
    <div class="card bg-light">
      <div class="card-header">COUNTRY</div>
      <div class="card-body">
        <p class="card-text ">NUMBER OF COUNTRY: <span class="text-warning"><h3><?php echo  get_country_count() ?> </h3></span></p>
        <a href="display_country.php" class="btn btn-danger" target="_blank">VIEW COUNTRYS</a>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card bg-light">
      <div class="card-header">STATE</div>
      <div class="card-body">
        <p class="card-text">NUMBER OF STATE: <span class="text-warning"><h3><?php echo  get_state_count() ?></h3></span></p>
        <a href="display_state.php" class="btn btn-warning" target="_blank">VIEW STATE</a>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card bg-light">
      <div class="card-header">CITY</div>
      <div class="card-body">
        <p class="card-text">NUMBER OF CITY: <span class="text-warning"><h3> <?php echo  get_city_count() ?></h3></span></p>
        <a href="display_district.php" class="btn btn-primary" target="_blank">VIEW CITY</a>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card bg-light">
      <div class="card-header">THESIL</div>
      <div class="card-body">
        <p class="card-text">NUMBER OF THESIL:<span class="text-warning"><h3><?php echo  get_thesil_count() ?></h3></span></p>
        <a href="display_thesil.php " class="btn btn-success" target="_blank">VIEW THESIL</a>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card bg-light">
      <div class="card-header">PINCODE</div>
      <div class="card-body">
        <p class="card-text">NUMBER OF PINCODE: <span class="text-warning"><h3><?php echo  get_pincode_count() ?> </h3></span></p>
        <a href="display_pincode.php" class="btn btn-info" target="_blank">VIEW PINCODE</a>
      </div>
    </div>
  </div>
</div>








</body>
</html>