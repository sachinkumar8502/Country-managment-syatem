<?php 
include('connection.php');
//print_r($_POST);

 $country=   $_POST['country'];
$state_id =   $_POST['state'];
$district =  $_POST['district'];
$district_id        = $_POST['district_id'];
   
    $sql = 'UPDATE `tbldistrict` SET `country_id`="'.$country.'" , `state_id`="'.$state_id.'", `district_name`="'.$district.'"  WHERE district_id ="'. $district_id.'" ';
       
   $retval = $conn->query($sql);
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($conn));
   }
    echo 'Updated';
?>