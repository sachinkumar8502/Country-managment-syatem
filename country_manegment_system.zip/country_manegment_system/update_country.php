<?php
include('connection.php');
//print_r($_POST);

  

$country=   $_POST['country'];
$country_id        = $_POST['country_id'];
   
    $sql = 'UPDATE `tblcountry` SET `country_name`="'.$country.'" WHERE country_id ="'. $country_id.'" ';
       
   $retval = $conn->query($sql);
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($conn));
   }
    echo 'Updated';
?>
