<?php
include('connection.php');
//print_r($_POST);
   $country_id = $_POST['country'];
  $state_id = $_POST['state'];
  $district=   $_POST['district'];
  $thesil = $_POST['thesil'];
  $pincode=   $_POST['pincode'];

  
  
  $sql ='INSERT INTO `insert_tbl_data`(`country_name`, `state_name`, `district_name`, `thesil_name`, `pin_code`)
  VALUES ("'.$country_id.'" , "'.$state_id.'" , "'.$district.'" ,"'.$thesil.'", "'.$pincode.'")';

  $retval = $conn->query($sql);
  if(! $retval ) {
     die('Could not enter data: ' . mysqli_error($conn));
  }
  echo "success";
?>