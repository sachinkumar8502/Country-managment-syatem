<?php
include("connection.php");

$deledata = trim($_POST['state_id']);

        if(!empty($deledata)){
        $qry = "DELETE FROM `tblstate` WHERE state_id ='$deledata'";
        $result=mysqli_query( $conn,$qry);
        if($result){

            echo 'Deleted';

            }else{
                echo 'error';

            }
        }else{
                echo 'id empty !';
        }

?>