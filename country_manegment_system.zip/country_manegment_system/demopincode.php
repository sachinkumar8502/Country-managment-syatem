<?php 
include('connection.php');
		
$sql = 'SELECT * FROM `tblcountry`';

   $result = $conn->query($sql);
   if(! $result ) {
      die('Could not enter data: ' . mysqli_error($conn));
  }

?>
<!DOCTYPE html>
<html>
<head>
	<title>view cms data</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
</head>
<body>


<div class="card">
  <div class="card-header">
    <b>View pincode</b>
  </div>
  <div class="card-body">
    <table class="table ">
 
    <tr>
      <th scope="col">id</th>
      <th scope="col">Country</th>
      <th scope="col">state</th>
      <th scope="col">district</th>
      <th scope="col">pincode</th>
      <th scope="col">Action</th>
</tr>
<?php
$i=0;
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
  $i++;
  
  $country_id = $row['country_id']; 
  
  $sql1 = 'SELECT * FROM `tblstate` WHERE country_id = '. $country_id;
      $result1 = $conn->query($sql1);
?>

    <tr>
      <td><?php $i; ?></td>
      <td><?php echo ucfirst($row['country_name']); ?></td>
      <td colspan="4">
        <table class="table">
        <?php 

                    $z=0;
                    while ($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC)) {
                    $z++;

                    $state_id = $row1['state_id'];
                    

                    $sql2 = 'SELECT * FROM `tbldistrict` WHERE state_id = '. $state_id;
                    $result2 = $conn->query($sql2);

?>
              <tr>
                  <td><?php echo  ucfirst($row1['state_name']) ;?></td>
              <td>
                  <table class="table">
                  <?php  
                          $h=0;
                            while ($row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
                          $h++;

                          $district_id = $row2['district_id'];


                          $sql3 = 'SELECT * FROM `tblpincode` WHERE district_id = '. $district_id;
                          $result3 = $conn->query($sql3);


										?>
                        <tr>
                              <td ><?php echo ucfirst($row2['district_name']) ; ?></td>
                              <td >
                                    <table class="table">
                                    <?php 
                                        $y=0;
                                      while ($row5 = mysqli_fetch_array($result3, MYSQLI_ASSOC)) {
                                        $y++;
                                      ?>
                                            <tr id="del-<?php echo $row5['pincode_id']; ?>">
                                              <td><?php echo $row5['pin_code']; ?></td>
                                                  <td>
                                                  <button class="btn btn-success bg-dark">
                                                        <a onclick="deleteRecord(this.title);"title="<?php echo $row5['pincode_id']; ?>"><i class="fas fa-trash-alt"></i>Delete </a>
                                                    </button>

                                                        <button class="btn btn-success bg-dark ">
                                                <a class="text-white " style="text-decoration: none;" href="Pincode.php?pincode_id=<?php echo $row5['pincode_id']; ?>" title="<?php echo $row5['pincode_id']; ?>" onclick="return confirm('Are you sure you want to update?');"><i class="fas fa-edit"></i>Edit</a>
                                                    </button >
                                                  </td>
                                            </tr>
                                            <?php } ?>  
                                    </table>
                              </td>
                        </tr>
                        <?php } ?>
                  </table>


              </td>


            </tr>
            <?php } ?>
        </table>


      </td>


  </tr>
  
   <?php } ?>
</table>
   
  </div>
</div>

<script type="text/javascript">
  function deleteRecord(pincode_id){
console.log(pincode_id);

   $.ajax({
            type: "POST",
            url: "http://localhost/country_manegment_system/delete_country_process.php",
            data: 'pincode_id='+pincode_id,
            success: function(data){


                 console.log(data);

               //alert(data);
          $('#del-'+pincode_id).hide();


            },
            error: function(xhr, options, error) {
                 alert(error);
            }
        });
}
	
</script>

</body>
</html>

