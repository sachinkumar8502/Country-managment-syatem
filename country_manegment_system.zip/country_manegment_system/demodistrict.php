<?php 
include('connection.php');
		
  $sql = 'SELECT * FROM `tblcountry`';


   $result = $conn->query($sql);
   if(!$result){
      die('Could not enter data: ' . mysqli_error($conn));
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>view cms data</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light ">
  <a class="navbar-brand text-dark" href="cms_dashbord.php">Country Manegment System(CMS)</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="container-fluid">
<ul class="nav navbar-nav navbar-center">
 
  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Country</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="country.php">Add New Country</a>
      <a class="dropdown-item text-success" href="display_country.php">View Country</a>
      <a class="dropdown-item" href="#"></a>
    </div>
  </li>

  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>States</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="state.php">Add New State</a>
      <a class="dropdown-item text-success" href="display_state.php">View state</a>
      <a class="dropdown-item" href="#"></a>
    </div>
  </li>

   <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>District</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="district.php">Add New District</a>
      <a class="dropdown-item text-success" href="display_district.php">View District</a>
      <a class="dropdown-item" href="#"></a>
    </div>
    </li>
   <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Tehsil</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="thesil.php">Add New Tehsil</a>
        <a class="dropdown-item text-success" href="display_thesil.php">View Tehsil</a>
        <a class="dropdown-item" href="#"></a>
      </div>
    </li>

    <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Pincode</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="Pincode.php">Add New Pincode</a>
        <a class="dropdown-item text-success" href="display_pincode.php">View Pincode</a>
        <a class="dropdown-item" href="#"></a>
      </div>
    </li>

    <li class="nav-item">
      <a href="auto_complete.php" class="nav-link"><b>Users</b></a>
    </li>
   
</ul>
</div>
  </div>
</nav>

<div class="card">
  <div class="card-header">
    <b>View District</b>
  </div>
  <div class="card-body">
    <table class="table table-striped table-dark">
 
    <tr>
      <th scope="col">id</th>
      <th scope="col">Country</th>
      <th scope="col">state</th>
      <th scope="col">district</th>
      <th scope="col">Action</th>

    </tr>
  <?php
    
  $i=0;
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
      $i++;

  ?>
 
    <tr id="del-<?php echo $row['district_id']; ?>">  
      
      <td><?php echo $i ; ?></td>
       <td><?php echo ucfirst($row['country_name']) ; ?></td>
       
        <td><?php echo ucfirst($row['state_name']) ; ?></td>
        <td><?php echo ucfirst($row['district_name']) ; ?></td>
      
      <td>
      <button class="btn btn-success bg-dark">
          <a onclick="deleteRecord(this.title);"title="<?php echo $row['district_id']; ?>"><i class="fas fa-trash-alt"></i>Delete </a>
      </button>

        <button class="btn btn-success bg-dark ">
        <a class="text-white " style="text-decoration: none;" href="district.php?district_id=<?php echo $row['district_id']; ?>" title="<?php echo $row['district_id']; ?>" onclick="return confirm('Are you sure you want to update?');"><i class="fas fa-edit"></i>Edit</a>
      </button >
      </td>
    </tr>
    <?php } ?>
   
</table>
    
  </div>
</div>

<script type="text/javascript">
  function deleteRecord(district_id){
console.log(district_id);

   $.ajax({
            type: "POST",
            url: "http://localhost/country_manegment_system/delete_country_process.php",
            data: 'district_id='+district_id,
            success: function(data){


                 console.log(data);

               alert(data);
          $('#del-'+district_id).hide();


            },
            error: function(xhr, options, error) {
                 alert(error);
            }
        });
}
	
</script>

</body>
</html>
