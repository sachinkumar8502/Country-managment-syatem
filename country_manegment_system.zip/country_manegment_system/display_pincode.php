<?php 
include('connection.php');
		
  /*$sql = 'SELECT  tp.pincode_id,tp.state_id,tp.country_id,tp.pin_code,tp.district_id,tc.country_name,ts.state_name,td.district_name
  FROM tblpincode AS tp
  INNER JOIN tblcountry AS tc ON tc.country_id=tp.country_id
    INNER JOIN tblstate AS ts ON ts.state_id=tp.state_id
    INNER JOIN tbldistrict AS td ON td.district_id=tp.district_id';*/
    $sql = 'SELECT * FROM `tblcountry`';

   $result = $conn->query($sql);
   if(! $result ) {
      die('Could not enter data: ' . mysqli_error($conn));
  }

?>
<!DOCTYPE html>
<html>
<head>
	<title>view cms data</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
	<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css">
</head>
<body>
  <style>
    td.pincode {
    width: 66%;
}
    td.jjj {
        width: 48%;
    }
    li a.active {
  background-color: #04AA6D;
  color: white;
}

li a:hover:not(.active) {
  background-color:#bda047;
  color: white;
}
.overlay{
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 999;
    background: rgba(255,255,255,0.8) url("img/loader3.gif") center no-repeat;
}
.table-bordered td, .table-bordered th {
    border: 2px solid #223548;
    color: mediumvioletred;
}
.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    min-height: 1px;
    padding: 1.25rem;
    background-color: palegoldenrod;
}
  </style>

<nav class="navbar navbar-expand-lg navbar-light bg-light ">
  <a class="navbar-brand text-dark" href="cms_dashbord.php">Country Manegment System(CMS)</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="container-fluid">
<ul class="nav navbar-nav navbar-center">
 
  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Country</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="country.php">Add New Country</a>
      <a class="dropdown-item text-success" href="display_country.php">View Country</a>
      <a class="dropdown-item" href="#"></a>
    </div>
  </li>

  <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>States</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="state.php">Add New State</a>
      <a class="dropdown-item text-success" href="display_state.php">View state</a>
      <a class="dropdown-item" href="#"></a>
    </div>
  </li>

   <li class="nav-item dropdown">
  <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>District</b></a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item text-success" href="district.php">Add New District</a>
      <a class="dropdown-item text-success" href="display_district.php">View District</a>
      <a class="dropdown-item" href="#"></a>
    </div>
    </li>
   <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Tehsil</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="thesil.php">Add New Tehsil</a>
        <a class="dropdown-item text-success" href="display_thesil.php">View Tehsil</a>
        <a class="dropdown-item" href="#"></a>
      </div>
    </li>

    <li class="nav-item dropdown">
    <a href="" class="nav-link text-white dropdown-toggle text-dark" data-toggle="dropdown"><b>Pincode</b></a>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item text-success" href="Pincode.php">Add New Pincode</a>
        <a class="dropdown-item text-success" href="display_pincode.php">View Pincode</a>
        <a class="dropdown-item" href="#"></a>
      </div>
    </li>

    <li class="nav-item">
      <a href="auto_complete.php" class="nav-link"><b>Users</b></a>
    </li>
   
</ul>
</div>
  </div>
</nav>

<div class="card">
  <div class="card-header">
    <b>View pincode</b>
  </div>
  <div class="card-body">
    <table class="table table-bordered">
 
    <tr>
      <th scope="col">id</th>
      <th scope="col">Country</th>
      <th scope="col">state</th>
      <th scope="col">district</th>
      <th scope="col">pincode</th>
      <th scope="col">Action</th>
</tr>
<?php
$i=0;
while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
  $i++;
  
  $country_id = $row['country_id']; 
  
  $sql1 = 'SELECT * FROM `tblstate` WHERE country_id = '. $country_id;
      $result1 = $conn->query($sql1);
?>

    <tr>
      <td><?php $i; ?></td>
      <td><?php echo ucfirst($row['country_name']); ?></td>
      <td colspan="4">
        <table class="table table-bordered">
        <?php 

                    $z=0;
                    while ($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC)) {
                    $z++;

                    $state_id = $row1['state_id'];
                    

                    $sql2 = 'SELECT * FROM `tbldistrict` WHERE state_id = '. $state_id;
                    $result2 = $conn->query($sql2);

?>
              <tr>
                  <td><?php echo  ucfirst($row1['state_name']) ;?></td>
              <td>
                  <table class="table table-bordered">
                  <?php  
                          $h=0;
                            while ($row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
                          $h++;

                          $district_id = $row2['district_id'];


                          $sql3 = 'SELECT * FROM `tblpincode` WHERE district_id = '. $district_id;
                          $result3 = $conn->query($sql3);


										?>
                        <tr>
                              <td ><?php echo ucfirst($row2['district_name']) ; ?></td>
                              <td class="pincode" >
                                    <table class="table table-bordered">
                                    <?php 
                                        $y=0;
                                      while ($row5 = mysqli_fetch_array($result3, MYSQLI_ASSOC)) {
                                        $y++;
                                      ?>
                                            <tr id="del-<?php echo $row5['pincode_id']; ?>">
                                              <td class="jjj"><?php echo $row5['pin_code']; ?></td>
                                                  <td>
                                                  <button class="btn btn-success bg-dark" onclick="return confirm('Are you sure you want to delete?');">
                                                        <a onclick="deleteRecord(this.title);"title="<?php echo $row5['pincode_id']; ?>"><i class="fas fa-trash-alt"></i><span onclick="spinner()">Delete</span> </a>
                                                    </button>

                                                        <button class="btn btn-success bg-dark ">
                                                <a class="text-white " style="text-decoration: none;" href="Pincode.php?pincode_id=<?php echo $row5['pincode_id']; ?>" title="<?php echo $row5['pincode_id']; ?>" onclick="return confirm('Are you sure you want to update?');"><i class="fas fa-edit"></i><span onclick="spinner()">Edit</span></a>
                                                <script>
                                                    function spinner() {
                                                      document.getElementsByClassName("overlay")[0].style.display = "block";
                                                    }
                                              </script>
                                                    </button >
                                                  </td>
                                            </tr>
                                            <?php } ?>  
                                    </table>
                              </td>
                        </tr>
                        <?php } ?>
                  </table>


              </td>


            </tr>
            <?php } ?>
        </table>


      </td>


  </tr>
  
   <?php } ?>
</table>
   
  </div>
</div>
<div class="overlay"></div>

<script type="text/javascript">
  function deleteRecord(pincode_id){
    function spinner() {
   
       
  }
console.log(pincode_id);
document.getElementsByClassName("overlay")[0].style.display = "block";

   $.ajax({
            type: "POST",
            url: "http://localhost/country_manegment_system/delete_pincode_process.php",
            data: 'pincode_id='+pincode_id,
            success: function(data){


                 console.log(data);
                 if (data.trim() == 'Deleted') {
             
             $('.overlay').hide();
             
           }

               //alert(data);
          $('#del-'+pincode_id).hide();


            },
            error: function(xhr, options, error) {
                 alert(error);
            }
        });
}
	
</script>

</body>
</html>

