<?php
include('connection.php');
//print_r($_POST);
  $country_id = $_POST['country'];
  $state_id = $_POST['state'];
  $district=   $_POST['district'];

  $districtquary= "SELECT * FROM tbldistrict WHERE district_name = '$district'";
  $quary = mysqli_query($conn,$districtquary);
  $district_count = mysqli_num_rows($quary);
  if ($district_count > 0) {
    echo "district_name";
    die();
  }
  
  $sql ='INSERT INTO `tbldistrict`( `country_id`, `state_id`, `district_name`)
  VALUES ("'.$country_id.'" , "'.$state_id.'" , "'.$district.'")';

  $retval = $conn->query($sql);
  if(! $retval ) {
     die('Could not enter data: ' . mysqli_error($conn));
  }
  echo "success";
?>