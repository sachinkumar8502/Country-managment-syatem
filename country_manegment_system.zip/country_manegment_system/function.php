<?php
function get_country_count(){
include('connection.php');
  $country_count ="";
  $query="SELECT count(*) as country_count from tblcountry";
  $query_run = mysqli_query($conn,$query);
  while ($row = mysqli_fetch_assoc($query_run)) {
    $country_count = $row['country_count'];
  }
  return($country_count);
}
//print_r($country_count);


 function get_state_count(){
	include('connection.php');
  $state_count ="";
  $query="SELECT count(*) as state_count from tblstate";
  $query_run = mysqli_query($conn,$query);
  while ($row = mysqli_fetch_assoc($query_run)) {
    $state_count = $row['state_count'];
  }
  return($state_count);
}

	function get_city_count(){
	include('connection.php');
	  $city_count ="";
	  $query="SELECT count(*) as city_count from tbldistrict";
	  $query_run = mysqli_query($conn,$query);
	  while ($row = mysqli_fetch_assoc($query_run)) {
	    $city_count = $row['city_count'];
	  }
	  return($city_count);
	}


	function get_thesil_count(){
	include('connection.php');
	  $thesil_count ="";
	  $query="SELECT count(*) as thesil_count from tbltehsil";
	  $query_run = mysqli_query($conn,$query);
	  while ($row = mysqli_fetch_assoc($query_run)) {
	    $thesil_count = $row['thesil_count'];
	  }
	  return($thesil_count);
	}

function get_pincode_count(){
	include('connection.php');
	  $pincode_count ="";
	  $query="SELECT count(*) as pincode_count from tblpincode";
	  $query_run = mysqli_query($conn,$query);
	  while ($row = mysqli_fetch_assoc($query_run)) {
	    $pincode_count = $row['pincode_count'];
	  }
	  return($pincode_count);
	}


?>