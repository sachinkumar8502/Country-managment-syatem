<?php 
include('connection.php');
//print_r($_POST);

  

$country=   $_POST['country'];
$state =   $_POST['state'];
$state_id        = $_POST['state_id'];
   
    $sql = 'UPDATE `tblstate` SET `country_id`="'.$country.'" , `state_name`="'.$state.'" WHERE state_id ="'. $state_id.'" ';
       
   $retval = $conn->query($sql);
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error($conn));
   }
    echo 'Updated';
?>