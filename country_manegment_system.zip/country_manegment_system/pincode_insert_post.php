<?php 
include('connection.php');  
if (isset($_POST["district_id"])) {
    $district_id= $_POST['district_id'];
    $querypincode = "SELECT * FROM tblpincode WHERE district_id = '$district_id'ORDER BY pin_code ASC";
    $run_querypincode = mysqli_query($conn,$querypincode);
    $count = mysqli_num_rows($run_querypincode);
    if($count > 0){
        echo '<option value="">Select pincode</option>';
        while($row = mysqli_fetch_array($run_querypincode)){
		$pincode_id=$row['pincode_id'];
        $pin_code = $row['pin_code']; 
       	echo "<option value='$pincode_id'>$pin_code</option>";
        }
    }else{
        echo '<option value="">pincode not available</option>';
    }
    
}
?>