<?php
include('connection.php');
//print_r($_POST);

  $country=   $_POST['country']; //country

  
  $countryquary= "SELECT * FROM tblcountry WHERE country_name = '$country'";
  $quary = mysqli_query($conn,$countryquary);
  $country_count = mysqli_num_rows($quary);
  if ($country_count > 0) {
    echo "country_name";
    die();
  }

  
  
$sql ='INSERT INTO `tblcountry`( `country_name`)
  VALUES ("'.$country.'")';

  $retval = $conn->query($sql);
  if(! $retval ) {
     die('Could not enter data: ' . mysqli_error($conn));
  }
  echo "success";
?>
