<?php
include('connection.php');
//print_r($_POST);
   $country_id = $_POST['country'];
  $state_id = $_POST['state'];
  $district=   $_POST['district'];
  $pincode=   $_POST['pincode'];

  $pincodequary= "SELECT * FROM tblpincode WHERE pin_code = '$pincode'";
  $quary = mysqli_query($conn,$pincodequary);
  $pincode_count = mysqli_num_rows($quary);
  if ($pincode_count > 0) {
    echo "pin_code";
    die();
  }
  
  $sql ='INSERT INTO `tblpincode`( `country_id`, `state_id`, `district_id`, `pin_code`)
  VALUES ("'.$country_id.'" , "'.$state_id.'" , "'.$district.'" , "'.$pincode.'")';

  $retval = $conn->query($sql);
  if(! $retval ) {
     die('Could not enter data: ' . mysqli_error($conn));
  }
  echo "success";
?>